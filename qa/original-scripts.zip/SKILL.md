---
name: 蜡笔小新桌宠
description: Desktop pet companion for TeleAgent (蜡笔小新桌宠). Summon and control an animated transparent desktop pet that follows task progress via file-driven bubbles. Use when user mentions 桌宠, 小新, 蜡笔小新, 陪伴, 召唤宠物, 隐藏宠物, 切换桌宠状态, or wants a pet to accompany their work with real-time progress display. Supports idle/working/review/waiting/celebrate/failed states, multi-task independent bubbles (PySide6/Qt), and one-click deployment. Auto-checks deployment status on skill load; installs environment if missing.
name_cn: 蜡笔小新桌宠
description_cn: TeleAgent 蜡笔小新桌宠，多任务动态气泡、实时展示任务进度
create_source: super-agent-skill-creator
---
# 蜡笔小新桌宠

PySide6 (Qt6) 蜡笔小新桌宠，高清透明精灵 + 高频动画状态机 + 漫画风动态气泡 + 自动感知 + 任务文件驱动。所有安装、环境、配置集成在技能内，拷贝即用。

不要下载程序、访问网络或重新生成桌宠素材。使用本 Skill 自带的脚本。

## 自动感知（已恢复）

桌宠常驻后**自动跟随** TeleAgent 工作状态，无需 agent 手动写任务文件。

**原理**：每 250ms 增量读取 `teleagent.db` 的 `part` 表（按 rowid 游标不丢事件），按 `type` 字段映射状态：

| part type | 含义 | 桌宠状态 | 气泡内容 |
|---|---|---|---|
| `reasoning` | agent 思考中 | thinking（紫） | 思考中 |
| `tool`（read/grep/glob） | 只读工具 | review（青） | 读取文件/搜索… + 文件名 |
| `tool`（write/edit/powershell） | 写/执行工具 | working（蓝） | 执行命令/编辑文件… + 中文描述或文件名 |
| `step-finish`（reason=stop） | 助手输出完 | done → 招手庆祝 | — |
| `text`（用户消息） | 用户提问 | thinking | 思考中 |

**气泡内容**：气泡外观由 Qt 实时绘制，不使用带固定文字的图片。第一行状态 + 步骤数（如"执行命令 · 第 3 步"），第二行根据实时事件提取具体动作（优先工具 description、文件名或搜索关键词；不显示命令/正文）。只有手动 `state` 命令没有实时事件时，才使用简短的状态兜底文案。

**多会话**：每个会话一个独立气泡（标题 + 状态色），竖向堆叠可折叠，各自独立更新。

**气泡稳定性**：只要 `session-status.json` 中有 running 会话，气泡就不会因短暂无事件而消失；完成/结束后自动回落待机。

**系统内部会话过滤**：标题以 `[skill-evolution]`、`_SYS_` 开头的会话（技能进化 internal、记忆日志等后台系统会话）自动识别并排除——不显示气泡、不参与状态仲裁、不计入活跃会话。

**隐私**：只取结构字段（事件类型、工具名、会话 id、时间戳）+ 工具描述/文件名，命令正文、消息正文一律不读、不存、不显示。

## 排查工具

桌宠异常时用以下脚本定位（均只读、不联网）：

- `scripts/pet-status.py`：查看桌宠"眼里"的当前状态（`--watch` 持续跟踪），用于确认自动感知是否正常工作、气泡内容是否正确。
- `scripts/pet-log.py`：对比思维链原文与气泡摘录（`-n 20` / `--watch`），用于调气泡显示策略。
- `scripts/pet-check.py`：部署状态检查（`DEPLOYED` / `READY` / `NEED_INSTALL` 三态）。

## 自动部署（调用技能时自动执行）

加载本 Skill 即运行 `scripts/pet-check.py` 检查部署状态：

| 状态 | 含义 | 自动动作 |
|---|---|---|
| `DEPLOYED` | 已部署 + 运行中 | 直接进入任务陪伴 |
| `READY` | 已部署未运行 | 自动启动桌宠 |
| `NEED_INSTALL` | 未部署/依赖缺失 | 询问用户 → 运行 `install-env.ps1` → 启动 |

**权限确认点**（涉及系统级操作时先用提问工具确认）：
- 写登录自启 `Startup\CrayonShinchanPet.bat`（系统级更改）
- 无 PySide6 时在技能 `.venv` 内 `pip install PySide6`（联网安装）
- 其余（生成 config.json、建目录、启动）静默执行

## 一键安装

新机器或 `NEED_INSTALL` 时执行：

```powershell
pwsh -NoProfile -ExecutionPolicy Bypass -File <技能目录>\scripts\install-env.ps1
# 有 PowerShell 7 (pwsh) 优先用（效率高）；没有 pwsh 则用 powershell.exe（兼容 5.1）
# -NoAutostart 跳过登录自启；-Force 覆盖已有配置；-PipIndex https://pypi.org/simple 换 pip 源
# -SetupProfile 跳过交互直接初始化记忆系统
```

自动完成：Python 探测（优先 TeleAgent 内置，缺则建 venv 装 PySide6）→ 生成 config.json → 建任务目录 → 写登录自启。

安装结束后会交互式询问是否初始化用户记忆系统（输入 Y 确认）。授权后自动创建：
- **USER.md**：用户偏好档案（交互输入称呼、工作场景，随使用自动积累习惯和规范）
- **MEMORY.md**：系统核心事实记忆（随对话自动积累）
- **daily-log/**：每日日志目录（TeleAgent 自动写入每日对话摘要）
- **PATHS.md**：记忆路径说明

所有记忆数据仅存在本地，不上传、不联网。跳过后随时可重新运行 `install-env.ps1 -SetupProfile` 补建。

**首次部署说明（全新机器）**：TeleAgent 自带 Python 运行时，但**不带 PySide6**；首次安装需联网一次性下载（约 100MB，默认走清华镜像源）。Windows 防火墙默认放行出站 HTTPS，通常无需配置；若企业防火墙/代理拦截出站 443 导致 pip 失败，放行或换源后重试。安装完成后完全离线运行，不联网、不对外端口。

## 启动

```powershell
python <技能目录>\scripts\pet-start.py
# --status 查状态 / --stop 退出 / --foreground 前台调试
```

已运行则静默跳过（单实例，host.pid 探测）。也可双击 `scripts/start-pet.ps1` 或运行 `python scripts/pet-start.py`。

## 状态控制

`shinchan-pet.ps1` 写 state.json 控制桌宠。**不要用 `-Command start`**（会拉起旧宿主造成双开），召唤用 `pet-start.py`。

```powershell
$Ctl = Join-Path (Split-Path -Parent $PSScriptRoot) 'scripts\shinchan-pet.ps1'
# 切换状态
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command state -State running
# 庆祝（结束后自动回 idle）
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command celebrate
# 消息气泡
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command message -State running -Message '正在处理（2/4）'
# 显示/隐藏/退出/查询
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command show|hide|stop|status
```

## 多任务命令

```powershell
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command task-add -TaskName '处理数据' -TaskTotal 4
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command task-update -TaskId 't01...' -TaskCurrent 2 -TaskStatus running -TaskMessage '去重中…'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command task-complete -TaskId 't01...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Ctl -Command task-clear
```

## 多任务独立文件驱动（推荐）

往任务目录写文件，桌宠自动显示独立气泡。多任务并行各自独立，竖向堆叠，默认折叠。

**目录**：`<config.json paths.tasks_dir>`（默认 `D:\Desktop\.temp\pet-tasks`）

**文件格式**：

```
# 纯文本 <任务名>.txt
正在读取数据…
[2/5]正在归因
[完成]报告已生成

# JSON <任务名>.json
{"status":"running","current":2,"total":4,"message":"正在归因"}
```

状态值：`running`(蓝) `thinking`(紫) `completed`(绿) `failed`(红) `pending`(灰)

**心跳约定**：每完成关键步骤重写文件刷新心跳。正常结束删除文件。>15 秒未更新自动视为中断消失。

```powershell
$dir = 'D:\Desktop\.temp\pet-tasks'  # 以 config.json 为准
[System.IO.File]::WriteAllText((Join-Path $dir '读取CSV.txt'), '正在读取…', (New-Object System.Text.UTF8Encoding($false)))
Remove-Item -LiteralPath (Join-Path $dir '读取CSV.txt') -Force  # 结束
```

## 进度文件驱动（单气泡）

**路径**：`<config.json paths.progress_file>`（默认 `D:\Desktop\.temp\pet-progress.txt`）

纯文本 → 气泡消息；JSON `{state,message,tasks[]}` → 多任务面板。写空或删除即退出驱动回待机。

## 任务联动工作流

**默认：自动感知已恢复，桌宠自动跟随任务状态。** 不需要在提示词里写"先召唤桌宠"，不需要在任务过程中逐条切换状态。

只有以下情况需要主动下命令：
- 桌宠还没启动 → 执行 `start` 召唤一次（之后一直常驻）。
- 想让桌宠做特定动作（庆祝、招手、跳跃）→ 用 `celebrate` / `state`。

### 多步骤任务（推荐）

1. 开始任务前 `start` 召唤桌宠（已运行则跳过）。
2. 桌宠自动从 teleagent.db 增量读取，跟随每一步工具调用。
3. 全部完成后自动 `celebrate`（招手庆祝）回待机。

### 简单任务

1. `start` → 桌宠自动跟随。
2. 需要强制指定状态时：`state -State running/review/waiting/failed`。
3. 成功 → `celebrate`（自动回 idle）。

桌宠控制是陪伴效果，不得替代任务执行或进度说明。不在回复中逐条播报控制命令。

## state 值

`idle` `running` `review` `waiting` `failed` `waving` `jumping` `running-left` `running-right` `look`

## 交互

- 左键拖动改变位置（位置保存）
- 双击招手
- 右键菜单
- `Ctrl+Alt+P` 召回到鼠标所在屏幕
- 仅本机运行，不联网，不读工作区内容