#!/usr/bin/env python3
"""蜡笔小新桌宠启动器 — 自动挑一个装了 PySide6 的解释器来跑桌宠。

直接双击或命令行运行均可：

    python scripts/pet-start.py              # 后台启动（已运行则不动）
    python scripts/pet-start.py --foreground # 前台运行，方便看报错
    python scripts/pet-start.py --status     # 只看状态，不启动
    python scripts/pet-start.py --stop       # 退出桌宠

启动后桌宠会常驻。任务进度由任务文件/进度文件驱动（见 SKILL.md），无需再做任何操作。
"""

import os
import sys
import json
import time
import shutil
import subprocess
from pathlib import Path

# 禁止写入 .pyc 缓存（技能目录需保持纯净，技能广场审核禁止 .pyc）
sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import pet_config
MAIN = HERE / "shinchan_pet_qt.py"
RUNTIME = Path(os.environ.get("LOCALAPPDATA", "")) / "CrayonShinchanPet"
STATE = RUNTIME / "state.json"
PID_FILE = RUNTIME / "host.pid"


def candidates():
    """按优先级列出可能装了 PySide6 的解释器（统一走 pet_config，见 config.json）"""
    out = []
    # 1) pet_config 解析出的解释器（config > TeleAgent 内置 > 当前解释器 > PATH）
    exe = pet_config.python_executable()
    if exe:
        out.append(Path(exe))
    # 2) 本机 py 启动器 / PATH 里的 python
    out.append(Path("py"))
    out.append(Path("python"))
    # 3) 常见安装位置
    out += sorted((Path.home() / "AppData" / "Local" / "Programs" / "Python").glob("*/python.exe"), reverse=True)
    return out


def has_pyside6(exe: str) -> bool:
    try:
        r = subprocess.run(
            [exe, "-c", "import PySide6, PySide6.QtWidgets"],
            capture_output=True, timeout=60,
        )
        return r.returncode == 0
    except Exception:
        return False


def pick_interpreter():
    seen = set()
    for c in candidates():
        key = str(c).lower()
        if key in seen:
            continue
        seen.add(key)
        exe = str(c)
        if c.is_absolute() and not c.exists():
            continue
        if has_pyside6(exe):
            # GUI 程序用 pythonw 启动，避免桌宠背后跟一个黑色控制台窗口
            pw = c.with_name("pythonw.exe") if c.is_absolute() else None
            if pw is not None and pw.exists():
                return str(pw)
            return exe
    return None


def is_running():
    if not PID_FILE.exists():
        return False
    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return False
    try:
        if os.name == "nt":
            # 中文 Windows 的 tasklist 输出是 GBK，按字节比对，绕开编码问题
            r = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}"],
                capture_output=True, timeout=20,
            )
            return str(pid).encode() in r.stdout
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def stop():
    try:
        RUNTIME.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps({"command": "exit"}), encoding="utf-8")
        print("已发送退出指令")
    except Exception as e:
        print(f"退出失败: {e}")


def main():
    args = sys.argv[1:]
    if "--stop" in args:
        stop()
        return 0

    if "--status" in args:
        print(f"桌宠运行中: {is_running()}")
        return 0

    if is_running():
        print("桌宠已在运行，无需重复启动")
        return 0

    exe = pick_interpreter()
    if not exe:
        print("没找到装了 PySide6 的 Python。请先安装：")
        print("  pip install PySide6")
        return 1

    print(f"使用解释器: {exe}")
    foreground = "--foreground" in args
    try:
        if foreground:
            return subprocess.call([exe, str(MAIN)])
        if os.name == "nt":
            # Windows：用 Start-Process 派生独立进程，避免进程随 agent 命令
            # 结束被沙箱回收（subprocess.Popen 的子进程会挂在命令进程树上）。
            ps = shutil.which("powershell.exe") or "powershell.exe"
            start = (f"Start-Process -FilePath '{exe}' "
                     f"-ArgumentList '-B','{MAIN}' -WindowStyle Hidden")
            subprocess.Popen(
                [ps, "-NoProfile", "-NonInteractive", "-Command", start],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
            )
        else:
            subprocess.Popen(
                [exe, str(MAIN)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        # 等一下确认真的起来了
        for _ in range(20):
            time.sleep(0.25)
            if is_running():
                print("桌宠已启动，等待任务文件驱动进度")
                return 0
        print("桌宠进程已拉起，但未能确认 PID 文件，请查看界面是否出现")
        return 0
    except Exception as e:
        print(f"启动失败: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
