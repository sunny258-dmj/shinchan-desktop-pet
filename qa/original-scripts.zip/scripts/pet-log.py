#!/usr/bin/env python3
"""蜡笔蜡笔小新气泡对比日志 — 直观对比"界面思维链原文"和"气泡实际显示的内容"。

    python pet-log.py            # 对比最近 10 条思考
    python pet-log.py -n 20      # 最近 20 条
    python pet-log.py --watch    # 持续跟踪新思考（Ctrl+C 停止）

两行对比：
  [思维链开头] 界面上这段思考从头读起的样子
  [气泡·头部取] 当前采用的策略（前 42 字 + …）

数据源：teleagent.db 的 part 表（reasoning 块）。
本工具只在控制台打印，不写任何内容文件、不联网。
"""

import sys
import os
import time
import re
import sqlite3
import json

# 禁止写入 .pyc 字节码缓存（技能目录需保持纯净，技能广场审核禁止 .pyc）
sys.dont_write_bytecode = True

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pet_events import _db_path, _fit_text

WIDTH = 42


def tail_text(s, n=WIDTH):
    s = re.sub(r"\s+", " ", str(s)).strip()
    if len(s) <= n:
        return s
    return "…" + s[-n:]


def short_ts(ms):
    t = time.localtime(ms / 1000)
    return time.strftime("%H:%M:%S", t)


def dump_block(ms, full):
    full_flat = re.sub(r"\s+", " ", full).strip()
    print(f"\n[{short_ts(ms)}] 一段思考（原文 {len(full_flat)} 字）")
    head = _fit_text(full, WIDTH)
    tail = tail_text(full, WIDTH)
    print(f"  思维链开头   : {full_flat[:WIDTH + 10]}{'…' if len(full_flat) > WIDTH + 10 else ''}")
    print(f"  气泡·头部取 ✓: {head}")
    print(f"  气泡·尾部取 ✗: {tail}")


def fetch_reasoning(db, since_ts=0, limit=50):
    """从 part 表拉 reasoning 块：(time_created, text)。"""
    out = []
    try:
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        rows = cur.execute(
            "SELECT time_created, data FROM part "
            "WHERE time_created > ? AND data LIKE '%\"type\":\"reasoning\"%' "
            "ORDER BY time_created ASC LIMIT ?",
            (since_ts, limit),
        ).fetchall()
        for r in rows:
            try:
                d = json.loads(r["data"])
            except Exception:
                continue
            if d.get("type") != "reasoning":
                continue
            text = d.get("text", "") or ""
            if text.strip():
                out.append((r["time_created"], text))
        conn.close()
    except Exception:
        pass
    return out


def main():
    args = sys.argv[1:]
    watch = "--watch" in args or "-w" in args
    n = 10
    if "-n" in args:
        i = args.index("-n")
        try:
            n = int(args[i + 1])
        except Exception:
            pass

    db = _db_path()
    if not os.path.exists(db):
        print(f"找不到事件库: {db}")
        return 1

    print("蜡笔蜡笔小新气泡对比日志 — 气泡显示 vs 思维链原文（只处理思考块）")
    print("=" * 62)
    collected = fetch_reasoning(db, limit=400)
    if not collected:
        print("（最近没有思考块）")
        return 0
    for ms, full in collected[-n:]:
        dump_block(ms, full)

    if watch:
        print("\n--- 持续跟踪中，Ctrl+C 停止 ---")
        last_ts = collected[-1][0] if collected else 0
        try:
            while True:
                for ms, full in fetch_reasoning(db, since_ts=last_ts, limit=50):
                    if ms <= last_ts:
                        continue
                    last_ts = ms
                    dump_block(ms, full)
                time.sleep(2)
        except KeyboardInterrupt:
            pass
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())