# 蜡笔小新桌宠

独立的 TeleAgent / PySide6 桌宠。原始形象素材已保留，修复后的程序通过实测，可从以下入口启动：

```powershell
& .\scripts\start-pet.ps1
```

已有 Python + PySide6 时无需安装，也不要求先创建 config.json。拖动保存位置，双击挥手，右键切换状态；Ctrl+Alt+P 召回。如果快捷键被其他软件占用，可使用 `shinchan-pet.ps1 -Command reset-position`。

## 2026-09-09 修复

- **图片取帧**：原图 3072×4576 的人物位置没有对齐均匀网格，导致切头、串行。新增 `assets/spritesheet-layout.json`，记录 88 帧的实际取图区域与显示位置，运行时绘制到透明帧中。原 PNG 未修改。
- **动画**：修正左右跟随；垂直方向使用正面，避免误用背影。减少待机闪动；工作不再突然站起，等待不再躺倒，循环避开装饰物被切断的源帧。
- **事件**：rowid 分页避免同毫秒事件遗漏；跟踪工具原记录中的完成/失败更新；消息角色使用真实字段；按会话保活，清理完成状态和旧工具文案。
- **气泡与控制**：相同状态也能更新消息和步数；隐藏同步隐藏气泡；接通 state.json 的多任务列表；进度文件独立工作；清空时收回任务卡；多气泡避免重叠，跟随桌宠所在显示器。
- **启动**：统一 Python/PowerShell 入口；使用操作系统文件锁防止双开；修复把 Python 脚本交给 PowerShell 执行的问题；支持空格和单引号路径；退出释放日志和实例锁。
- **显示**：中文文字按完整内容计算高度；任务卡提高背景不透明度；动态内容按纯文本显示；位置保存与召回补齐。

## 测试与检查材料

- [详细检查报告](qa/检查报告.md)
- [动画前后对比](qa/animation-preview.html)（在本地浏览器中打开）
- [修复后的实际播放帧](qa/qt-played-frames.png)
- [本地 20 项回归测试](qa/tests-after.txt)
- [TeleAgent 实际执行记录](qa/teleagent-test.txt)（第一轮 14 项，全部通过）
- [启动入口测试](qa/launcher-test.txt)
- [修改差异](qa/changes.patch) / [原脚本备份](qa/original-scripts.zip)

原素材没有完整、准确的上/下凝视姿势，因此本次不宣称实现完整八方向凝视。多气泡超出屏幕容量时会隐藏放不下的卡片，未增加滚动列表。自动跟随仅接入 TeleAgent。

复测使用已有 PySide6 的 Python：

```powershell
python -X utf8 -B -m unittest discover -s tests -v
python -X utf8 -B tests\render_smoke.py
python -X utf8 -B tests\launcher_smoke.py
```

图片检查脚本 `scripts/inspect-assets.py` 另需 Pillow，桌宠日常运行不需要 Pillow。
